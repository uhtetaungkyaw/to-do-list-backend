package com.demo.todolist.enumeration;

public enum RepeatType {

    EVERYDAY, EVERY_WEEK, EVERY_MONTH

}
